# Betting App - Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/vladracoare/pen/YzEXveV](https://codepen.io/vladracoare/pen/YzEXveV).

